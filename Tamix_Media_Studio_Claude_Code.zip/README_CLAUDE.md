# Tamix Media Studio

Paquete de producto e implementación preparado para Claude Code.

## Qué contiene

- Prototipo navegable del dashboard y sus ocho módulos.
- Especificación funcional completa.
- Modelo de datos multi-tenant.
- Contrato REST, webhooks e ingestión.
- Roles y permisos.
- Backlog priorizado con dependencias.
- Criterios de aceptación y pruebas.
- Variables de entorno documentadas.

## Inicio rápido

```bash
npm ci
npm run dev
```

Claude Code debe leer primero `CLAUDE.md` y ejecutar el backlog desde P0. El prototipo actual usa datos de demostración: no debe confundirse con backend terminado.

## Estrategia de integración

1. Copiar las superficies visuales y componentes necesarios dentro del repositorio principal de `app.tamix.app`.
2. Montar las rutas bajo `/panel` sin alterar la navegación general.
3. Reutilizar sesión, usuarios, organizaciones, medios, publicaciones y eventos existentes.
4. Aplicar las migraciones faltantes del modelo descrito en `docs/DATA_MODEL.md`.
5. Sustituir adaptadores demo por servicios reales módulo por módulo.

## Resultado esperado

Un medio puede registrarse y verificar su dominio; invitar a su equipo; crear, importar, aprobar y programar contenido; gestionar conversaciones; medir atención y tráfico atribuido; conectar sus sistemas; y consultar ingresos y liquidaciones.
