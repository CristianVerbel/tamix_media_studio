# Tamix Media Studio — instrucciones maestras para Claude Code

## Misión

Implementar Media Studio dentro de la aplicación Tamix existente. Es el centro de operaciones para medios, autores institucionales y marcas aliadas: creación, distribución, programación, comunidad, analítica, monetización, integraciones y equipos.

No construir una aplicación paralela ni reescribir la lógica actual de Tamix. Integrar este paquete bajo `/panel`, conservar autenticación, Supabase/API, rutas, estados, permisos, eventos y analítica existentes.

## Orden de lectura obligatorio

1. `CLAUDE.md`
2. `README_CLAUDE.md`
3. `docs/PRODUCT_SPEC.md`
4. `docs/DATA_MODEL.md`
5. `docs/API_CONTRACT.md`
6. `docs/IMPLEMENTATION_BACKLOG.md`
7. `docs/ACCEPTANCE_TESTS.md`

## Fuente visual y de interacción

- Prototipo: `app/page.tsx` y `app/globals.css`.
- URL de referencia publicada: `https://tamix-media-studio.cristian473620.chatgpt.site`.
- Preservar el sistema Tamix existente: Inter para interfaz, Newsreader para lectura editorial, radios de 18/24 px, shell máximo de 1248 px, WCAG AA y foco visible.
- Marca maestra: Tamix. No deformar el logo ni sustituirlo por texto genérico.
- Claro `#F7F7F8`, oscuro `#0D0E11`, texto `#101114`.
- El gradiente ultravioleta–magenta–coral se reserva para isotipo, CTA y activos destacados. Evitar neón, glow, glassmorphism y 3D.
- Logos de medios se muestran sin alterar colores ni proporciones.
- Tamaño táctil mínimo: 44×44 px. Respetar `prefers-reduced-motion`.

## Rutas inmutables

No renombrar rutas ni claves internas ya utilizadas por Tamix.

- `/panel` — resumen ejecutivo.
- `/panel/contenido` — biblioteca, estados y editor.
- `/panel/planificador` — calendario y colas.
- `/panel/comunidad` — bandeja y moderación.
- `/panel/metricas` — tráfico y atención.
- `/panel/ingresos` — monetización y liquidaciones.
- `/panel/integraciones` — API, webhooks, RSS y CMS.
- `/panel/equipo` — miembros, roles y auditoría.
- `/panel/configuracion` — publicación y organización.
- `/para-medios` y `/para-medios/registro` — adquisición y alta.
- `/admin` y `/confianza` — administración, reportes y apelaciones.

Las rutas generales Tamix continúan siendo Inicio, Leer, Directos, Avisos, Descubrir y Publicar. La experiencia de lectura conserva `/lectura`, `/articulo/:id`, `/articulo/:id/original` y `/guardados`.

## Reglas de ingeniería

- Stack objetivo: Next.js 16, React 19, TypeScript estricto, Tailwind 4, componentes Shadcn existentes, Supabase/Postgres y almacenamiento compatible con S3.
- Separar UI, dominio, acceso a datos e integraciones. No consultar Supabase directamente desde componentes visuales.
- Multi-tenant obligatorio: toda entidad operativa pertenece a `organization_id`; aplicar RLS y verificar pertenencia en servidor.
- Usar Server Actions o Route Handlers para mutaciones. Validar entradas con Zod.
- Fechas en UTC; presentar según `organization.timezone`.
- Operaciones externas idempotentes mediante `idempotency_key`.
- No guardar claves API o secretos en navegador, repositorio, logs ni payloads analíticos.
- Webhooks salientes firmados con HMAC SHA-256, timestamp, reintentos exponenciales y dead-letter queue.
- Publicación programada debe usar una cola durable. Nunca depender de `setTimeout` o del navegador.
- Mantener registro de auditoría append-only para publicaciones, permisos, integraciones y liquidaciones.
- No usar datos simulados cuando el endpoint real exista. Durante migración, encapsular mocks detrás de adapters explícitos.
- Cada mutación debe contemplar loading, success, error, retry y permisos insuficientes.

## Roles base

- `owner`: facturación, claves, integraciones, roles y todo el contenido.
- `admin`: equipo, configuración y operación editorial; sin transferencia de propiedad.
- `editor`: crea, edita, aprueba, programa, publica y corrige.
- `author`: crea y edita sus contenidos; envía a revisión.
- `community_manager`: responde, modera y usa respuestas guardadas.
- `analyst`: solo lectura de métricas y exportaciones.
- `finance`: ingresos, reparto, facturas y liquidaciones.

Permitir roles personalizados a partir de permisos atómicos. Las validaciones del servidor son la autoridad; ocultar botones no es autorización.

## Estados editoriales

`draft → in_review → approved → scheduled → publishing → published`

Estados alternos: `rejected`, `failed`, `unpublished`, `archived`.

- Solo `editor`, `admin` u `owner` pueden aprobar y publicar.
- Una corrección posterior a publicación crea una versión y evento de auditoría.
- Una publicación programada puede reprogramarse o cancelarse hasta que entre en `publishing`.
- Contenido Premium requiere configuración válida de Tamix Pass.

## Métricas canónicas

- Alcance único.
- Impresiones.
- Inicio de lectura.
- Lectura completa.
- Tiempo activo de atención.
- Progreso 25/50/75/100%.
- Guardados, compartidos, comentarios útiles y seguidores ganados.
- CTR hacia el dominio original.
- Tráfico atribuido al medio.
- Conversión a Tamix Pass y revenue atribuible.

No usar pageviews como sinónimo de lectura. Excluir bots, prerender y tiempo inactivo. Detalles en `docs/PRODUCT_SPEC.md`.

## API y webhooks

Seguir `docs/API_CONTRACT.md`. Versionar bajo `/api/v1`. Respuestas con `data`, `meta` y `error`; IDs UUID; paginación por cursor. API keys con scopes, hash en reposo, rotación y fecha de última utilización.

Eventos webhook iniciales:

- `content.created`, `content.updated`, `content.approved`.
- `content.scheduled`, `content.published`, `content.failed`.
- `comment.created`, `mention.created`, `moderation.reported`.
- `integration.sync.completed`, `integration.sync.failed`.
- `subscription.started`, `revenue.statement.ready`, `payout.paid`.

## Definición de terminado

Una historia no está terminada hasta que:

1. Funciona con datos persistentes y aislamiento multi-tenant.
2. Tiene autorización de servidor.
3. Registra eventos y auditoría cuando aplica.
4. Incluye estados vacío, carga, error y éxito.
5. Es usable con teclado, móvil y 200% de zoom.
6. Tiene pruebas del camino principal y del rechazo por permisos.
7. No rompe rutas ni contratos existentes.
8. Cumple los criterios de `docs/ACCEPTANCE_TESTS.md`.

## Secuencia de implementación

Ejecutar los épicos P0→P3 de `docs/IMPLEMENTATION_BACKLOG.md`. No iniciar monetización avanzada antes de cerrar identidad, organizaciones, roles, contenido, scheduler e ingestión. Al terminar cada épico, correr typecheck, pruebas del módulo y pruebas de integración pertinentes.

## Comandos

```bash
npm ci
npm run dev
npm run build
npm run lint
```

Antes de modificar dependencias, comprobar si la capacidad ya existe. Conservar `package-lock.json`.
