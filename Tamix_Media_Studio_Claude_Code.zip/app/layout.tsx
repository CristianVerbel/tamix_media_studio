import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "Tamix Media Studio", description: "Centro de operaciones para medios y marcas aliadas de Tamix.", icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" } };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="es"><body>{children}</body></html>; }
