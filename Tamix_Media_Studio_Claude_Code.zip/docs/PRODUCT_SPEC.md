# Especificación funcional

## 1. Alta de medios

Flujo: crear organización → datos legales/editoriales → reclamar dominio → verificar por DNS TXT, archivo HTML o meta tag → conectar fuente → importar muestra → invitar equipo → revisión de confianza → activar.

Estados: `draft`, `pending_domain`, `pending_review`, `active`, `restricted`, `rejected`.

## 2. Resumen

Debe mostrar KPIs del periodo, variación comparada, rendimiento temporal, calidad de atención, contenido reciente, conversaciones pendientes, salud de integraciones y accesos rápidos. Todos los valores respetan organización, zona horaria, rango y filtros activos.

## 3. Contenido

Tipos: post corto, artículo, carrusel, imagen, video, podcast, directo y enlace externo. Funciones: crear, editar, duplicar, previsualizar, versionar, enviar a revisión, aprobar, programar, publicar, corregir, retirar y archivar.

Campos comunes: título, cuerpo, resumen, autor, medio, temas, assets, canonical URL, visibilidad, premium, SEO, distribución y programación.

## 4. Planificador

Vistas día/semana/mes/lista. Drag-and-drop reprograma solo con permiso. Detecta conflictos, zona horaria y contenidos sin aprobar. Sugiere horarios usando historial, pero nunca publica automáticamente sin configuración explícita.

## 5. Comunidad

Bandeja unificada de comentarios, respuestas, menciones, mensajes y reportes. Filtros por estado, contenido, responsable, prioridad y sentimiento como ayuda no vinculante. Acciones: responder, asignar, ocultar, reportar, bloquear, escalar y guardar respuesta.

Moderación sensible siempre permite revisión humana y apelación. La IA propone; una persona decide salvo reglas explícitas contra spam inequívoco.

## 6. Métricas e insights

Dimensiones: contenido, autor, formato, tema, fuente, dispositivo, país, seguidor/no seguidor y periodo. Comparaciones y exportación CSV. Insights deben explicar evidencia, periodo, tamaño de muestra y acción sugerida.

Definiciones:

- Alcance: usuarios únicos expuestos.
- Lectura completa: progreso ≥90% o final visible con tiempo activo mínimo.
- Atención activa: tiempo con documento visible y actividad reciente; pausa tras 30 s inactivo.
- Conversación útil: comentario no eliminado que supera filtros de calidad y recibe interacción significativa.
- Tráfico enviado: apertura del original atribuida con identificador firmado.

## 7. Monetización

Tamix Pass, contenido premium, suscripciones, revenue share, publicidad contextual e inteligencia B2B. El Studio muestra ingresos estimados, ajustes, ingresos netos, reparto, impuestos, liquidaciones y estado de pago. Toda cifra debe indicar moneda, periodo y condición estimada/final.

## 8. Integraciones

- API REST: gestión e ingestión.
- Webhooks entrantes: eventos desde CMS autorizados.
- Webhooks salientes: notificaciones firmadas.
- RSS/Atom: importación periódica con deduplicación por canonical URL y hash.
- CMS: WordPress primero mediante adapter; arquitectura extensible.
- Dominio: verificación y atribución.

Cada conexión muestra estado, última sincronización, latencia, volumen, errores recientes, reintento y desconexión segura.

## 9. Equipo

Invitaciones con vencimiento, roles base, permisos personalizados, 2FA recomendable para owner/admin, sesiones activas y auditoría. Revocar un miembro invalida sesiones y claves personales.

## 10. Requisitos no funcionales

- P95 de lectura del dashboard <800 ms después de caché.
- Publicación programada con desviación objetivo <60 s.
- Entrega webhook at-least-once e idempotencia del consumidor.
- Exportaciones grandes asíncronas.
- Cifrado en tránsito y secretos cifrados en reposo.
- Retención configurable y borrado compatible con legislación aplicable.
