# Criterios de aceptación

## Multi-tenant y permisos

- Un miembro de Acento no puede leer, inferir ni modificar datos de otro medio.
- Un `author` no puede aprobar ni publicar.
- Un `analyst` no puede mutar contenido.
- Revocar membership bloquea la siguiente solicitud y sesiones activas.

## Contenido

- Guardar borrador conserva todos los campos y assets.
- Aprobar registra revisor, fecha y versión.
- Programar en el pasado falla con mensaje accionable.
- Dos solicitudes con la misma idempotency key generan una sola publicación.
- Una falla externa deja el contenido recuperable y visible en salud de conexiones.

## Ingestión

- Repetir un item RSS no crea duplicados.
- Cambiar el item crea nueva versión cuando corresponde.
- HTML peligroso se sanitiza.
- Canonical URL conserva atribución al medio.
- Credencial sin scope recibe 403.

## Webhooks

- Firma válida se verifica con raw body.
- Firma inválida y timestamp vencido se rechazan.
- Entregas fallidas reintentan según política.
- Replay manual no duplica efectos.

## Comunidad

- Responder registra autor y contexto.
- Moderar exige permiso y auditoría.
- Reporte puede escalarse y apelarse.
- Datos privados no aparecen en exportaciones no autorizadas.

## Métricas

- Bots y prerender no suman alcance ni atención.
- Inactividad pausa el tiempo activo.
- Rangos respetan zona horaria de la organización.
- Totales coinciden entre tarjetas, tabla y exportación para el mismo filtro.
- Insight muestra evidencia, periodo y tamaño de muestra.

## Monetización

- Ledger no se edita ni elimina.
- Ajuste crea asiento compensatorio.
- Statement diferencia estimado de final.
- Usuario sin `finance.read` no accede a cifras ni exportaciones.

## UX y accesibilidad

- Navegación completa con teclado y foco visible.
- Controles utilizables en móvil y con zoom 200%.
- Contraste WCAG AA.
- Estados loading, vacío, error, permisos y éxito.
- `prefers-reduced-motion` elimina movimiento no esencial.

## Rendimiento

- Dashboard cacheado P95 <800 ms.
- Tablas grandes usan paginación/cursor.
- Exportaciones grandes no bloquean solicitud web.
- Bundle no incorpora secretos ni service role.
