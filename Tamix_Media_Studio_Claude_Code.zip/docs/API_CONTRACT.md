# Contrato API v1

Base: `/api/v1`. JSON UTF-8. Autenticación por sesión Tamix o `Authorization: Bearer tmx_...` para integraciones.

## Formato

```json
{"data": {}, "meta": {"requestId": "uuid"}, "error": null}
```

Error:

```json
{"data": null, "meta": {"requestId": "uuid"}, "error": {"code": "forbidden", "message": "No tienes permiso para publicar", "details": {}}}
```

## Endpoints principales

| Método | Ruta | Scope/permiso |
|---|---|---|
| GET | `/organizations/:id/dashboard` | `analytics.read` |
| GET/POST | `/organizations/:id/contents` | `content.read/create` |
| GET/PATCH | `/contents/:id` | `content.read/update` |
| POST | `/contents/:id/submit` | `content.submit` |
| POST | `/contents/:id/approve` | `content.approve` |
| POST | `/contents/:id/schedule` | `content.publish` |
| POST | `/contents/:id/publish` | `content.publish` |
| POST | `/contents/:id/unpublish` | `content.publish` |
| GET | `/organizations/:id/calendar` | `content.read` |
| GET | `/organizations/:id/conversations` | `community.read` |
| POST | `/conversations/:id/replies` | `community.reply` |
| POST | `/messages/:id/moderate` | `community.moderate` |
| GET | `/organizations/:id/analytics` | `analytics.read` |
| POST | `/organizations/:id/exports` | `analytics.export` |
| GET | `/organizations/:id/statements` | `finance.read` |
| GET/POST | `/organizations/:id/integrations` | `integrations.manage` |
| POST | `/integrations/:id/sync` | `integrations.manage` |
| GET/POST | `/organizations/:id/webhooks` | `integrations.manage` |
| POST | `/organizations/:id/api-keys` | `api_keys.manage` |
| GET/POST | `/organizations/:id/members` | `team.manage` |
| GET | `/organizations/:id/audit-log` | `audit.read` |

Paginación: `?limit=50&cursor=opaque`. Máximo 100. Filtros repetibles y orden explícito.

## Ingestión

`POST /api/v1/ingest/content` acepta `externalId`, `canonicalUrl`, `type`, `title`, `body`, `summary`, `authors`, `assets`, `topics`, `publishedAt`, `updatedAt` y `metadata`. Requiere `Idempotency-Key`.

Reglas: upsert por `source + externalId`; fallback por canonical URL; conservar procedencia; sanitizar HTML; descargar assets solo desde hosts permitidos; rechazar scripts y esquemas no seguros.

## Firma de webhooks

Headers:

- `X-Tamix-Event-Id`
- `X-Tamix-Timestamp`
- `X-Tamix-Signature: v1=<hex>`

Firma: HMAC-SHA256 de `timestamp + "." + rawBody`. Rechazar timestamps con diferencia mayor a cinco minutos y deduplicar por event ID.

Payload:

```json
{
  "id": "evt_uuid",
  "type": "content.published",
  "occurredAt": "2026-09-16T15:00:00Z",
  "organizationId": "uuid",
  "actor": {"type": "user", "id": "uuid"},
  "object": {"type": "content", "id": "uuid"},
  "data": {}
}
```

Reintentos: inmediato, 1 min, 5 min, 30 min, 2 h, 12 h y 24 h. Después pasa a dead-letter y se notifica al administrador.

## Códigos

`400 invalid_request`, `401 unauthenticated`, `403 forbidden`, `404 not_found`, `409 conflict`, `422 validation_error`, `429 rate_limited`, `500 internal_error`, `503 dependency_unavailable`.
