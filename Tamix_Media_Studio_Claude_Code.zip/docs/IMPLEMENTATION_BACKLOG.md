# Backlog de implementación

## P0 — Fundamentos

1. Integrar shell `/panel` en la app existente.
2. Organizaciones, memberships, selección de medio y RLS.
3. Permisos atómicos y roles base.
4. Layout responsive, modo oscuro, accesibilidad y estados globales.
5. Auditoría y eventos normalizados.

Salida: un usuario solo ve y opera organizaciones autorizadas.

## P0 — Contenido y programación

1. CRUD de contenidos y assets.
2. Editor por tipo de contenido.
3. Versiones, revisión y aprobaciones.
4. Programación durable, publicación y reintentos.
5. Biblioteca con filtros, búsqueda, duplicación y archivo.
6. Calendario día/semana/mes/lista.

Salida: flujo `draft → published` completo, trazable e idempotente.

## P0 — Integraciones

1. API keys y scopes.
2. Endpoint de ingestión.
3. RSS/Atom con deduplicación.
4. Webhooks salientes firmados.
5. Verificación de dominio.
6. Adapter WordPress inicial.

Salida: Acento puede sincronizar contenido sin carga manual duplicada.

## P1 — Comunidad

1. Bandeja unificada.
2. Respuestas, asignación y estados.
3. Moderación, reportes y apelaciones.
4. Respuestas guardadas y SLA.
5. Notificaciones internas/email según preferencias.

## P1 — Métricas

1. Taxonomía de eventos.
2. Tiempo activo y progreso de lectura.
3. Agregaciones diarias.
4. Dashboard, comparaciones y filtros.
5. Atribución de tráfico al medio.
6. Exportaciones asíncronas.
7. Insights explicables.

## P2 — Monetización

1. Entitlements Tamix Pass.
2. Contenido premium.
3. Ledger y reglas de revenue share 10–15% configurables.
4. Statements, ajustes y liquidaciones.
5. Exportación y conciliación.

## P2 — Equipo y operación

1. Invitaciones y vencimiento.
2. Roles personalizados.
3. Sesiones, 2FA y revocación.
4. Registro de actividad.
5. Centro de salud de conexiones.

## P3 — Escala

1. Rate limits por organización/clave.
2. Colas DLQ y replay controlado.
3. Caché de dashboards.
4. Observabilidad, SLO y alertas.
5. Retención, exportación y borrado de datos.

## Regla de ejecución

Claude Code debe tomar un épico, producir plan corto, implementar migraciones/backend/UI/pruebas, verificar criterios y cerrar documentación antes de avanzar. No implementar pantallas desconectadas como “avance”.
