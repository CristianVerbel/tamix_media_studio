# Modelo de datos

Usar UUID, `created_at`, `updated_at` y `organization_id` donde aplique. Mantener tablas existentes y crear solo las faltantes.

| Entidad | Campos esenciales |
|---|---|
| `organizations` | name, slug, type, status, timezone, locale, currency |
| `organization_domains` | organization_id, domain, verification_method, token_hash, verified_at |
| `memberships` | organization_id, user_id, role_id, status, invited_by |
| `roles` | organization_id nullable, key, name, permissions jsonb |
| `contents` | organization_id, author_id, type, status, title, body_json, summary, visibility, premium, canonical_url |
| `content_versions` | content_id, version, snapshot_json, created_by, change_reason |
| `content_assets` | content_id, storage_key, mime_type, width, height, duration, alt_text |
| `content_schedules` | content_id, publish_at, timezone, state, queue_job_id, attempts |
| `content_channels` | content_id, channel, external_id, state, published_at, error_json |
| `editorial_reviews` | content_id, reviewer_id, decision, note, decided_at |
| `conversations` | organization_id, content_id, channel, external_id, state, assigned_to |
| `messages` | conversation_id, author_id, body, state, moderation_json |
| `moderation_cases` | organization_id, object_type, object_id, reason, state, assignee_id |
| `integrations` | organization_id, type, state, config_encrypted, last_sync_at |
| `api_keys` | organization_id, prefix, secret_hash, scopes, expires_at, last_used_at |
| `webhook_endpoints` | organization_id, url, secret_encrypted, subscribed_events, state |
| `webhook_deliveries` | endpoint_id, event_id, attempt, status_code, next_attempt_at, response_excerpt |
| `ingestion_sources` | organization_id, type, url, config_json, state, cursor, last_sync_at |
| `analytics_events` | organization_id, event_name, user_id, anonymous_id, content_id, session_id, occurred_at, properties |
| `daily_content_metrics` | organization_id, content_id, date, metric columns |
| `revenue_ledger` | organization_id, content_id, type, amount, currency, status, occurred_at |
| `statements` | organization_id, period_start, period_end, gross, adjustments, net, status |
| `payouts` | organization_id, statement_id, amount, currency, status, paid_at |
| `audit_logs` | organization_id, actor_id, action, object_type, object_id, before_json, after_json, ip_hash |

## Restricciones

- `contents(organization_id, canonical_url)` único cuando canonical URL no es nulo.
- `memberships(organization_id, user_id)` único.
- `analytics_events(event_id)` único para deduplicación.
- `webhook_deliveries(endpoint_id, event_id, attempt)` único.
- Ledger financiero append-only; ajustes mediante asientos compensatorios.

## Índices mínimos

- Contenido por organización, estado y fecha programada.
- Eventos por organización, contenido y fecha.
- Conversaciones por organización, estado y actualización.
- Auditoría por organización, objeto y fecha.
- Entregas webhook por estado y próximo intento.

## RLS

El usuario solo accede a organizaciones con membership activa. Finanzas requiere permiso específico. Service role se limita a workers, scheduler, ingestión y agregaciones; nunca se expone al cliente.
